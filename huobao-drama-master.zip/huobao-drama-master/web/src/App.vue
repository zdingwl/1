<template>
  <router-view />
</template>

<script setup lang="ts"></script>

<style>
#app {
  width: 100%;
  height: 100vh;
}
</style>
